/*
 * Copyright (c) 1999, 2018 Oracle and/or its affiliates. All rights reserved.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License v. 2.0, which is available at
 * http://www.eclipse.org/legal/epl-2.0.
 *
 * This Source Code may also be made available under the following Secondary
 * Licenses when the conditions for such availability set forth in the
 * Eclipse Public License v. 2.0 are satisfied: GNU General Public License,
 * version 2 with the GNU Classpath Exception, which is available at
 * https://www.gnu.org/software/classpath/license.html.
 *
 * SPDX-License-Identifier: EPL-2.0 OR GPL-2.0 WITH Classpath-exception-2.0
 */

package com.sun.ts.lib.util.sec.misc;

/**
 * This interface defines the contract a extension installation capable provided
 * to the extension installation dependency mechanism to install new extensions
 * on the user's disk
 *
 * @author Jerome Dochez
 */
public interface ExtensionInstallationProvider {

  /*
   * <p> Request the installation of an extension in the extension directory
   * </p>
   *
   * @param requestExtInfo information on the extension that need to be
   * installed
   * 
   * @param installedExtInfo information on the current compatible installed
   * extension. Can be null if no current installation has been found.
   * 
   * @return true if the installation is successful, false if the installation
   * could not be attempted.
   * 
   * @exception ExtensionInstallationException if an installation was attempted
   * but did not succeed.
   */
  boolean installExtension(ExtensionInfo requestExtInfo,
      ExtensionInfo installedExtInfo) throws ExtensionInstallationException;
}
